package br.com.projetoBecaEveris;

public class Pagamento {
	
	private Double  debito;
	private Double credito;
	private Double  dinheiro;
}
