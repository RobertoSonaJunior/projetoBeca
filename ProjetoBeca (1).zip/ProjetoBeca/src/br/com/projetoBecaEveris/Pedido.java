package br.com.projetoBecaEveris;

public class Pedido {

}
