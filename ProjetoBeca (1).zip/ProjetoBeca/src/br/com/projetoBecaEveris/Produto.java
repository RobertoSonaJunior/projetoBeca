package br.com.projetoBecaEveris;

public class Produto {
	
	private Double  preco;
	 
}
