package br.com.projetoBecaEveris;

public class Cliente {
	private String nome;
	private String telefone;
	private String email;
	
	
	public Cliente(String nome, String telefone, String email, String login, String senha) {
		this.nome = nome;
		this.telefone = telefone;
		this.email = email;
		
	}
	
	
	
//	fazer getter e setter//vem oculto
//	construtor de cada atributo?//vem oculto
//	
	
}
